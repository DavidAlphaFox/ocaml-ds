
open Creal
open Creal.Infixes
open Graphics

let pi = 3.1415926535
let xmin = -1.0
let xmax =  1.0
let ymin = -.pi
let ymax =  pi

let f = arccos

let w = 800
let h = 600
let g = Printf.sprintf " %dx%d" w h
let () = open_graph g; set_color black

let one_pixel = (xmax -. xmin) /. float w

let dx = xmax -. xmin
let dy = ymax -. ymin
let i x = truncate (float w *. (x -. xmin) /. dx)
let j y = truncate (float h *. (y -. ymin) /. dy)

let moveto x y = moveto (i x) (j y)
let lineto x y = lineto (i x) (j y)
let plot x y = plot (i x) (j y)

let () =
  moveto 0. ymin;
  lineto 0. ymax;
  moveto xmin 0.;
  lineto xmax 0.

let () = 
  for i = 0 to w - 1 do
    let x = of_float (xmin +. float i *. one_pixel) in
    let y = to_float (f x) 3 in
    Graphics.plot i (j y)
  done

let _ = wait_next_event [Key_pressed]
