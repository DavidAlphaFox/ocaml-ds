#load "cmpf.cmo";;
#install_printer Cmpf.pp;;
open Cmpf;;
let s = Cmpf.of_string;;
open Infixes;;
pi;;
